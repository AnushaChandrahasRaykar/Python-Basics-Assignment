$(document).ready(function(){

const responses = [
"That's interesting!",
"Tell me more.",
"I can help with that.",
"Great question!",
"Here’s something you can try."
];

/* Add message */

function addMessage(text, sender){

let messageClass = sender === "user" ? "user" : "ai";

let html = `
<div class="message ${messageClass}">
${text}
</div>
`;

$("#messages").append(html);

$("#messages").scrollTop(
$("#messages")[0].scrollHeight
);

}

/* Send message */

function sendMessage(){

let text = $("#messageInput").val().trim();

if(text === "") return;

addMessage(text, "user");

$("#messageInput").val("");

$(".welcome-screen").hide();

$("#typing").show();

setTimeout(function(){

$("#typing").hide();

let reply = responses[
Math.floor(Math.random() * responses.length)
];

addMessage(reply, "ai");

},1500);

}

/* Button click */

$("#sendBtn").click(function(){
sendMessage();
});

/* Enter key */

$("#messageInput").keydown(function(e){

if(e.key === "Enter" && !e.shiftKey){
e.preventDefault();
sendMessage();
}

});

/* Enable/disable button */

$("#messageInput").on("input", function(){

if($(this).val().trim() === ""){
$("#sendBtn").prop("disabled", true);
}else{
$("#sendBtn").prop("disabled", false);
}

});

/* Auto resize */

$("#messageInput").on("input", function(){

this.style.height = "auto";
this.style.height = this.scrollHeight + "px";

});

});
$("#darkToggle").click(function(){
$("body").toggleClass("dark");
});
$(".suggestion-card").click(function(){
let text = $(this).text();
$("#messageInput").val(text);
});