---
## How to Run

1. Open the project folder in VS Code  
2. Open `index.html`  
3. Right click and select **Open with Live Server**  

---

## Functionality

- User can type and send messages  
- AI responds with predefined responses  
- Typing animation is shown before AI reply  
- Messages are automatically scrolled  

---

##  Assignment Tasks Covered

- Task 1: HTML Structure  
- Task 2: CSS Styling  
- Task 3: JavaScript Functionality  
- Task 4: Responsive Design  

---

##  Bonus Features

- Typing indicator animation  
- Auto-resize input box  
- Enter key message sending  

---

## Screenshots

Screenshots for desktop, tablet, and mobile views are included in the `screenshots` folder.

---

## Author

Anusha Chandrahas Raykar
GenAI Intern